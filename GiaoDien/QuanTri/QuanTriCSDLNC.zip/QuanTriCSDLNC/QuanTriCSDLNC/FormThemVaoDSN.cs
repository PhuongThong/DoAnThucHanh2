﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace QuanTriCSDLNC
{
    public partial class FormThemVaoDSN : Form 
    {
        SqlConnection connection;
        SqlCommand commandSP;
        string str = @"Data Source=DESKTOP-OMQ9N0C\SQLEXPRESS;Initial Catalog=BanHangTrucTuyen;Integrated Security=True";
        private readonly FormQuanTri fQuanTri;
        public FormThemVaoDSN(FormQuanTri frm)
        {
            InitializeComponent();
            fQuanTri = frm;
        }

        private void buttonThemSPvaoDSN_Click(object sender, EventArgs e)
        {
            connection =new SqlConnection(str);
            connection.Open();  
            commandSP = new SqlCommand("usp_ThemVaoDSN", connection);
            commandSP.CommandType = CommandType.StoredProcedure;
            commandSP.Parameters.AddWithValue("@MaSP", textBoxMaSP_Them.Text);
            commandSP.Parameters.AddWithValue("@MaNCC", textBoxNCC_Them.Text);
            commandSP.Parameters.AddWithValue("@SoLuong", textBoxSLThem.Text);
            var rtn = commandSP.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
            rtn.Direction = ParameterDirection.ReturnValue;
            commandSP.ExecuteNonQuery();
            //rtn.Value = 0;
            if (rtn.Value.Equals(1))
            {
                string messages = "Thêm sản phẩm thành công";
                MessageBox.Show(messages);
                fQuanTri.loadData_DSN();
            }
            else
            {
                string messagef = "Không thể thêm sản phẩm! Mời bạn kiểm tra lại thông tin.";
                MessageBox.Show(messagef);
            }

        }

        private void buttonHuyThem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
