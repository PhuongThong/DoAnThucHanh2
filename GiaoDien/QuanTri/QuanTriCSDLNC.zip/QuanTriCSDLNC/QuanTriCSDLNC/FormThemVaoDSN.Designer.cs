﻿namespace QuanTriCSDLNC
{
    partial class FormThemVaoDSN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonHuyThem = new System.Windows.Forms.Button();
            this.buttonThemSPvaoDSN = new System.Windows.Forms.Button();
            this.textBoxMaSP_Them = new System.Windows.Forms.TextBox();
            this.labelThem_Ma = new System.Windows.Forms.Label();
            this.textBoxSLThem = new System.Windows.Forms.TextBox();
            this.labelSLSP = new System.Windows.Forms.Label();
            this.textBoxNCC_Them = new System.Windows.Forms.TextBox();
            this.labelNCC_Them = new System.Windows.Forms.Label();
            this.labelText = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonHuyThem
            // 
            this.buttonHuyThem.Location = new System.Drawing.Point(308, 267);
            this.buttonHuyThem.Name = "buttonHuyThem";
            this.buttonHuyThem.Size = new System.Drawing.Size(113, 33);
            this.buttonHuyThem.TabIndex = 8;
            this.buttonHuyThem.Text = "Hủy";
            this.buttonHuyThem.UseVisualStyleBackColor = true;
            this.buttonHuyThem.Click += new System.EventHandler(this.buttonHuyThem_Click);
            // 
            // buttonThemSPvaoDSN
            // 
            this.buttonThemSPvaoDSN.Location = new System.Drawing.Point(72, 267);
            this.buttonThemSPvaoDSN.Name = "buttonThemSPvaoDSN";
            this.buttonThemSPvaoDSN.Size = new System.Drawing.Size(113, 33);
            this.buttonThemSPvaoDSN.TabIndex = 7;
            this.buttonThemSPvaoDSN.Text = "Thêm";
            this.buttonThemSPvaoDSN.UseVisualStyleBackColor = true;
            this.buttonThemSPvaoDSN.Click += new System.EventHandler(this.buttonThemSPvaoDSN_Click);
            // 
            // textBoxMaSP_Them
            // 
            this.textBoxMaSP_Them.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMaSP_Them.Location = new System.Drawing.Point(219, 75);
            this.textBoxMaSP_Them.Name = "textBoxMaSP_Them";
            this.textBoxMaSP_Them.Size = new System.Drawing.Size(231, 27);
            this.textBoxMaSP_Them.TabIndex = 6;
            // 
            // labelThem_Ma
            // 
            this.labelThem_Ma.AutoSize = true;
            this.labelThem_Ma.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelThem_Ma.Location = new System.Drawing.Point(26, 78);
            this.labelThem_Ma.Name = "labelThem_Ma";
            this.labelThem_Ma.Size = new System.Drawing.Size(120, 20);
            this.labelThem_Ma.TabIndex = 5;
            this.labelThem_Ma.Text = "Mã sản phẩm: ";
            // 
            // textBoxSLThem
            // 
            this.textBoxSLThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSLThem.Location = new System.Drawing.Point(219, 193);
            this.textBoxSLThem.Name = "textBoxSLThem";
            this.textBoxSLThem.Size = new System.Drawing.Size(231, 27);
            this.textBoxSLThem.TabIndex = 10;
            // 
            // labelSLSP
            // 
            this.labelSLSP.AutoSize = true;
            this.labelSLSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSLSP.Location = new System.Drawing.Point(26, 200);
            this.labelSLSP.Name = "labelSLSP";
            this.labelSLSP.Size = new System.Drawing.Size(162, 20);
            this.labelSLSP.TabIndex = 9;
            this.labelSLSP.Text = "Số lượng sản phẩm: ";
            // 
            // textBoxNCC_Them
            // 
            this.textBoxNCC_Them.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNCC_Them.Location = new System.Drawing.Point(219, 137);
            this.textBoxNCC_Them.Name = "textBoxNCC_Them";
            this.textBoxNCC_Them.Size = new System.Drawing.Size(231, 27);
            this.textBoxNCC_Them.TabIndex = 12;
            // 
            // labelNCC_Them
            // 
            this.labelNCC_Them.AutoSize = true;
            this.labelNCC_Them.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNCC_Them.Location = new System.Drawing.Point(26, 140);
            this.labelNCC_Them.Name = "labelNCC_Them";
            this.labelNCC_Them.Size = new System.Drawing.Size(122, 20);
            this.labelNCC_Them.TabIndex = 11;
            this.labelNCC_Them.Text = "Nhà cung cấp: ";
            // 
            // labelText
            // 
            this.labelText.AutoSize = true;
            this.labelText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelText.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelText.Location = new System.Drawing.Point(31, 29);
            this.labelText.Name = "labelText";
            this.labelText.Size = new System.Drawing.Size(350, 20);
            this.labelText.TabIndex = 13;
            this.labelText.Text = "Nhập thông tin sản phẩm thêm vào danh sách";
            // 
            // FormThemVaoDSN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(467, 342);
            this.Controls.Add(this.labelText);
            this.Controls.Add(this.textBoxNCC_Them);
            this.Controls.Add(this.labelNCC_Them);
            this.Controls.Add(this.textBoxSLThem);
            this.Controls.Add(this.labelSLSP);
            this.Controls.Add(this.buttonHuyThem);
            this.Controls.Add(this.buttonThemSPvaoDSN);
            this.Controls.Add(this.textBoxMaSP_Them);
            this.Controls.Add(this.labelThem_Ma);
            this.Name = "FormThemVaoDSN";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thêm sản phẩm vào danh sách nhập";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonHuyThem;
        private System.Windows.Forms.Button buttonThemSPvaoDSN;
        private System.Windows.Forms.TextBox textBoxMaSP_Them;
        private System.Windows.Forms.Label labelThem_Ma;
        private System.Windows.Forms.TextBox textBoxSLThem;
        private System.Windows.Forms.Label labelSLSP;
        private System.Windows.Forms.TextBox textBoxNCC_Them;
        private System.Windows.Forms.Label labelNCC_Them;
        private System.Windows.Forms.Label labelText;
    }
}