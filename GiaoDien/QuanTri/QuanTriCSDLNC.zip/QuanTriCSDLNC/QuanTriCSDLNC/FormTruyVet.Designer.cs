﻿namespace QuanTriCSDLNC
{
    partial class FormTruyVet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTruyvet_Ma = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dataGridViewTruyVet = new System.Windows.Forms.DataGridView();
            this.buttonTruyVet_TV = new System.Windows.Forms.Button();
            this.buttonHuyTV = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTruyVet)).BeginInit();
            this.SuspendLayout();
            // 
            // labelTruyvet_Ma
            // 
            this.labelTruyvet_Ma.AutoSize = true;
            this.labelTruyvet_Ma.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTruyvet_Ma.Location = new System.Drawing.Point(12, 28);
            this.labelTruyvet_Ma.Name = "labelTruyvet_Ma";
            this.labelTruyvet_Ma.Size = new System.Drawing.Size(164, 20);
            this.labelTruyvet_Ma.TabIndex = 0;
            this.labelTruyvet_Ma.Text = "Nhập mã sản phẩm: ";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(205, 25);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(231, 27);
            this.textBox1.TabIndex = 1;
            // 
            // dataGridViewTruyVet
            // 
            this.dataGridViewTruyVet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTruyVet.Location = new System.Drawing.Point(18, 117);
            this.dataGridViewTruyVet.Name = "dataGridViewTruyVet";
            this.dataGridViewTruyVet.RowHeadersWidth = 51;
            this.dataGridViewTruyVet.RowTemplate.Height = 24;
            this.dataGridViewTruyVet.Size = new System.Drawing.Size(515, 289);
            this.dataGridViewTruyVet.TabIndex = 2;
            // 
            // buttonTruyVet_TV
            // 
            this.buttonTruyVet_TV.Location = new System.Drawing.Point(63, 66);
            this.buttonTruyVet_TV.Name = "buttonTruyVet_TV";
            this.buttonTruyVet_TV.Size = new System.Drawing.Size(113, 33);
            this.buttonTruyVet_TV.TabIndex = 3;
            this.buttonTruyVet_TV.Text = "Truy vết";
            this.buttonTruyVet_TV.UseVisualStyleBackColor = true;
            this.buttonTruyVet_TV.Click += new System.EventHandler(this.buttonTruyVet_TV_Click);
            // 
            // buttonHuyTV
            // 
            this.buttonHuyTV.Location = new System.Drawing.Point(372, 66);
            this.buttonHuyTV.Name = "buttonHuyTV";
            this.buttonHuyTV.Size = new System.Drawing.Size(113, 33);
            this.buttonHuyTV.TabIndex = 4;
            this.buttonHuyTV.Text = "Hủy";
            this.buttonHuyTV.UseVisualStyleBackColor = true;
            this.buttonHuyTV.Click += new System.EventHandler(this.buttonHuyTV_Click);
            // 
            // FormTruyVet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(555, 450);
            this.Controls.Add(this.buttonHuyTV);
            this.Controls.Add(this.buttonTruyVet_TV);
            this.Controls.Add(this.dataGridViewTruyVet);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.labelTruyvet_Ma);
            this.Name = "FormTruyVet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormTruyVet";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTruyVet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTruyvet_Ma;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dataGridViewTruyVet;
        private System.Windows.Forms.Button buttonTruyVet_TV;
        private System.Windows.Forms.Button buttonHuyTV;
    }
}