﻿namespace QuanTriCSDLNC
{
    partial class FormQuanTri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControlQuanTri = new System.Windows.Forms.TabControl();
            this.tabSanPham = new System.Windows.Forms.TabPage();
            this.buttonSuaGia = new System.Windows.Forms.Button();
            this.buttonXoaSP = new System.Windows.Forms.Button();
            this.buttonSuaSLT = new System.Windows.Forms.Button();
            this.buttonTruyVet = new System.Windows.Forms.Button();
            this.buttonThemSPVaoDSNhap = new System.Windows.Forms.Button();
            this.buttonThemSP = new System.Windows.Forms.Button();
            this.groupBoxSP_ThongTin = new System.Windows.Forms.GroupBox();
            this.textBoxSLT = new System.Windows.Forms.TextBox();
            this.labelSLT = new System.Windows.Forms.Label();
            this.textBoxMoTa = new System.Windows.Forms.TextBox();
            this.textBoxMaSP = new System.Windows.Forms.TextBox();
            this.textBoxGia = new System.Windows.Forms.TextBox();
            this.textBoxNCC = new System.Windows.Forms.TextBox();
            this.textBoxTenSP = new System.Windows.Forms.TextBox();
            this.labelMoTa = new System.Windows.Forms.Label();
            this.labelNCC = new System.Windows.Forms.Label();
            this.labelGiaSP = new System.Windows.Forms.Label();
            this.labelMaSP = new System.Windows.Forms.Label();
            this.labelTenSP = new System.Windows.Forms.Label();
            this.groupBoxSP_Data = new System.Windows.Forms.GroupBox();
            this.dataGridViewSanPham = new System.Windows.Forms.DataGridView();
            this.tabNhapHang = new System.Windows.Forms.TabPage();
            this.groupBoxDSDN = new System.Windows.Forms.GroupBox();
            this.dataGridViewDanhSachNH = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonTaoPN = new System.Windows.Forms.Button();
            this.textBoxMaNV = new System.Windows.Forms.TextBox();
            this.labelMaNV = new System.Windows.Forms.Label();
            this.textBoxNH_NCC = new System.Windows.Forms.TextBox();
            this.labelTruyVet_NCC = new System.Windows.Forms.Label();
            this.textBoxMPN = new System.Windows.Forms.TextBox();
            this.labelMPN = new System.Windows.Forms.Label();
            this.groupBoxNhapHang = new System.Windows.Forms.GroupBox();
            this.dataGridViewNhapHang = new System.Windows.Forms.DataGridView();
            this.buttonDangXuat = new System.Windows.Forms.Button();
            this.tabControlQuanTri.SuspendLayout();
            this.tabSanPham.SuspendLayout();
            this.groupBoxSP_ThongTin.SuspendLayout();
            this.groupBoxSP_Data.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSanPham)).BeginInit();
            this.tabNhapHang.SuspendLayout();
            this.groupBoxDSDN.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDanhSachNH)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBoxNhapHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewNhapHang)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControlQuanTri
            // 
            this.tabControlQuanTri.Controls.Add(this.tabSanPham);
            this.tabControlQuanTri.Controls.Add(this.tabNhapHang);
            this.tabControlQuanTri.Location = new System.Drawing.Point(7, 6);
            this.tabControlQuanTri.Name = "tabControlQuanTri";
            this.tabControlQuanTri.SelectedIndex = 0;
            this.tabControlQuanTri.Size = new System.Drawing.Size(790, 597);
            this.tabControlQuanTri.TabIndex = 0;
            // 
            // tabSanPham
            // 
            this.tabSanPham.Controls.Add(this.buttonSuaGia);
            this.tabSanPham.Controls.Add(this.buttonXoaSP);
            this.tabSanPham.Controls.Add(this.buttonSuaSLT);
            this.tabSanPham.Controls.Add(this.buttonTruyVet);
            this.tabSanPham.Controls.Add(this.buttonThemSPVaoDSNhap);
            this.tabSanPham.Controls.Add(this.buttonThemSP);
            this.tabSanPham.Controls.Add(this.groupBoxSP_ThongTin);
            this.tabSanPham.Controls.Add(this.groupBoxSP_Data);
            this.tabSanPham.Location = new System.Drawing.Point(4, 25);
            this.tabSanPham.Name = "tabSanPham";
            this.tabSanPham.Padding = new System.Windows.Forms.Padding(3);
            this.tabSanPham.Size = new System.Drawing.Size(782, 568);
            this.tabSanPham.TabIndex = 0;
            this.tabSanPham.Text = "Sản phẩm";
            this.tabSanPham.UseVisualStyleBackColor = true;
            this.tabSanPham.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // buttonSuaGia
            // 
            this.buttonSuaGia.Location = new System.Drawing.Point(577, 520);
            this.buttonSuaGia.Name = "buttonSuaGia";
            this.buttonSuaGia.Size = new System.Drawing.Size(120, 31);
            this.buttonSuaGia.TabIndex = 7;
            this.buttonSuaGia.Text = "Cập nhập giá";
            this.buttonSuaGia.UseVisualStyleBackColor = true;
            this.buttonSuaGia.Click += new System.EventHandler(this.buttonSuaGia_Click);
            // 
            // buttonXoaSP
            // 
            this.buttonXoaSP.Location = new System.Drawing.Point(327, 467);
            this.buttonXoaSP.Name = "buttonXoaSP";
            this.buttonXoaSP.Size = new System.Drawing.Size(122, 31);
            this.buttonXoaSP.TabIndex = 6;
            this.buttonXoaSP.Text = "Xóa";
            this.buttonXoaSP.UseVisualStyleBackColor = true;
            this.buttonXoaSP.Click += new System.EventHandler(this.buttonXoaSP_Click);
            // 
            // buttonSuaSLT
            // 
            this.buttonSuaSLT.Location = new System.Drawing.Point(577, 467);
            this.buttonSuaSLT.Name = "buttonSuaSLT";
            this.buttonSuaSLT.Size = new System.Drawing.Size(120, 31);
            this.buttonSuaSLT.TabIndex = 5;
            this.buttonSuaSLT.Text = "Cập nhập SLT";
            this.buttonSuaSLT.UseVisualStyleBackColor = true;
            this.buttonSuaSLT.Click += new System.EventHandler(this.buttonSua_Click);
            // 
            // buttonTruyVet
            // 
            this.buttonTruyVet.Location = new System.Drawing.Point(327, 520);
            this.buttonTruyVet.Name = "buttonTruyVet";
            this.buttonTruyVet.Size = new System.Drawing.Size(122, 31);
            this.buttonTruyVet.TabIndex = 4;
            this.buttonTruyVet.Text = "Truy vết ";
            this.buttonTruyVet.UseVisualStyleBackColor = true;
            this.buttonTruyVet.Click += new System.EventHandler(this.buttonTruyVet_Click);
            // 
            // buttonThemSPVaoDSNhap
            // 
            this.buttonThemSPVaoDSNhap.Location = new System.Drawing.Point(99, 520);
            this.buttonThemSPVaoDSNhap.Name = "buttonThemSPVaoDSNhap";
            this.buttonThemSPVaoDSNhap.Size = new System.Drawing.Size(122, 31);
            this.buttonThemSPVaoDSNhap.TabIndex = 3;
            this.buttonThemSPVaoDSNhap.Text = "Thêm vào DSN";
            this.buttonThemSPVaoDSNhap.UseVisualStyleBackColor = true;
            this.buttonThemSPVaoDSNhap.Click += new System.EventHandler(this.buttonThemSPVaoDSNhap_Click);
            // 
            // buttonThemSP
            // 
            this.buttonThemSP.Location = new System.Drawing.Point(99, 467);
            this.buttonThemSP.Name = "buttonThemSP";
            this.buttonThemSP.Size = new System.Drawing.Size(122, 31);
            this.buttonThemSP.TabIndex = 2;
            this.buttonThemSP.Text = "Thêm";
            this.buttonThemSP.UseVisualStyleBackColor = true;
            this.buttonThemSP.Click += new System.EventHandler(this.buttonThemSP_Click);
            // 
            // groupBoxSP_ThongTin
            // 
            this.groupBoxSP_ThongTin.Controls.Add(this.textBoxSLT);
            this.groupBoxSP_ThongTin.Controls.Add(this.labelSLT);
            this.groupBoxSP_ThongTin.Controls.Add(this.textBoxMoTa);
            this.groupBoxSP_ThongTin.Controls.Add(this.textBoxMaSP);
            this.groupBoxSP_ThongTin.Controls.Add(this.textBoxGia);
            this.groupBoxSP_ThongTin.Controls.Add(this.textBoxNCC);
            this.groupBoxSP_ThongTin.Controls.Add(this.textBoxTenSP);
            this.groupBoxSP_ThongTin.Controls.Add(this.labelMoTa);
            this.groupBoxSP_ThongTin.Controls.Add(this.labelNCC);
            this.groupBoxSP_ThongTin.Controls.Add(this.labelGiaSP);
            this.groupBoxSP_ThongTin.Controls.Add(this.labelMaSP);
            this.groupBoxSP_ThongTin.Controls.Add(this.labelTenSP);
            this.groupBoxSP_ThongTin.Location = new System.Drawing.Point(16, 285);
            this.groupBoxSP_ThongTin.Name = "groupBoxSP_ThongTin";
            this.groupBoxSP_ThongTin.Size = new System.Drawing.Size(763, 167);
            this.groupBoxSP_ThongTin.TabIndex = 1;
            this.groupBoxSP_ThongTin.TabStop = false;
            // 
            // textBoxSLT
            // 
            this.textBoxSLT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSLT.Location = new System.Drawing.Point(498, 120);
            this.textBoxSLT.Name = "textBoxSLT";
            this.textBoxSLT.Size = new System.Drawing.Size(170, 27);
            this.textBoxSLT.TabIndex = 11;
            this.textBoxSLT.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // labelSLT
            // 
            this.labelSLT.AutoSize = true;
            this.labelSLT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSLT.Location = new System.Drawing.Point(364, 127);
            this.labelSLT.Name = "labelSLT";
            this.labelSLT.Size = new System.Drawing.Size(107, 20);
            this.labelSLT.TabIndex = 10;
            this.labelSLT.Text = "Số lượng tồn:";
            this.labelSLT.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBoxMoTa
            // 
            this.textBoxMoTa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMoTa.Location = new System.Drawing.Point(498, 73);
            this.textBoxMoTa.Name = "textBoxMoTa";
            this.textBoxMoTa.Size = new System.Drawing.Size(170, 27);
            this.textBoxMoTa.TabIndex = 9;
            // 
            // textBoxMaSP
            // 
            this.textBoxMaSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMaSP.Location = new System.Drawing.Point(162, 73);
            this.textBoxMaSP.Name = "textBoxMaSP";
            this.textBoxMaSP.Size = new System.Drawing.Size(177, 27);
            this.textBoxMaSP.TabIndex = 8;
            // 
            // textBoxGia
            // 
            this.textBoxGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxGia.Location = new System.Drawing.Point(162, 120);
            this.textBoxGia.Name = "textBoxGia";
            this.textBoxGia.Size = new System.Drawing.Size(177, 27);
            this.textBoxGia.TabIndex = 7;
            // 
            // textBoxNCC
            // 
            this.textBoxNCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNCC.Location = new System.Drawing.Point(498, 27);
            this.textBoxNCC.Name = "textBoxNCC";
            this.textBoxNCC.Size = new System.Drawing.Size(170, 27);
            this.textBoxNCC.TabIndex = 6;
            // 
            // textBoxTenSP
            // 
            this.textBoxTenSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTenSP.Location = new System.Drawing.Point(162, 28);
            this.textBoxTenSP.Name = "textBoxTenSP";
            this.textBoxTenSP.Size = new System.Drawing.Size(177, 27);
            this.textBoxTenSP.TabIndex = 5;
            // 
            // labelMoTa
            // 
            this.labelMoTa.AutoSize = true;
            this.labelMoTa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMoTa.Location = new System.Drawing.Point(364, 80);
            this.labelMoTa.Name = "labelMoTa";
            this.labelMoTa.Size = new System.Drawing.Size(56, 20);
            this.labelMoTa.TabIndex = 4;
            this.labelMoTa.Text = "Mô tả:";
            // 
            // labelNCC
            // 
            this.labelNCC.AutoSize = true;
            this.labelNCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNCC.Location = new System.Drawing.Point(364, 30);
            this.labelNCC.Name = "labelNCC";
            this.labelNCC.Size = new System.Drawing.Size(117, 20);
            this.labelNCC.TabIndex = 3;
            this.labelNCC.Text = "Nhà cung cấp:";
            // 
            // labelGiaSP
            // 
            this.labelGiaSP.AutoSize = true;
            this.labelGiaSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGiaSP.Location = new System.Drawing.Point(28, 127);
            this.labelGiaSP.Name = "labelGiaSP";
            this.labelGiaSP.Size = new System.Drawing.Size(40, 20);
            this.labelGiaSP.TabIndex = 2;
            this.labelGiaSP.Text = "Giá:";
            // 
            // labelMaSP
            // 
            this.labelMaSP.AutoSize = true;
            this.labelMaSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMaSP.Location = new System.Drawing.Point(28, 80);
            this.labelMaSP.Name = "labelMaSP";
            this.labelMaSP.Size = new System.Drawing.Size(115, 20);
            this.labelMaSP.TabIndex = 1;
            this.labelMaSP.Text = "Mã sản phẩm:";
            // 
            // labelTenSP
            // 
            this.labelTenSP.AutoSize = true;
            this.labelTenSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTenSP.Location = new System.Drawing.Point(28, 30);
            this.labelTenSP.Name = "labelTenSP";
            this.labelTenSP.Size = new System.Drawing.Size(120, 20);
            this.labelTenSP.TabIndex = 0;
            this.labelTenSP.Text = "Tên sản phẩm:";
            // 
            // groupBoxSP_Data
            // 
            this.groupBoxSP_Data.Controls.Add(this.dataGridViewSanPham);
            this.groupBoxSP_Data.Location = new System.Drawing.Point(3, 13);
            this.groupBoxSP_Data.Name = "groupBoxSP_Data";
            this.groupBoxSP_Data.Size = new System.Drawing.Size(773, 266);
            this.groupBoxSP_Data.TabIndex = 0;
            this.groupBoxSP_Data.TabStop = false;
            this.groupBoxSP_Data.Text = "Danh sách sản phẩm";
            this.groupBoxSP_Data.Enter += new System.EventHandler(this.groupBoxSP_Data_Enter);
            // 
            // dataGridViewSanPham
            // 
            this.dataGridViewSanPham.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSanPham.Location = new System.Drawing.Point(5, 24);
            this.dataGridViewSanPham.Name = "dataGridViewSanPham";
            this.dataGridViewSanPham.RowHeadersWidth = 51;
            this.dataGridViewSanPham.RowTemplate.Height = 24;
            this.dataGridViewSanPham.Size = new System.Drawing.Size(767, 241);
            this.dataGridViewSanPham.TabIndex = 0;
            this.dataGridViewSanPham.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridViewSanPham.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // tabNhapHang
            // 
            this.tabNhapHang.Controls.Add(this.groupBoxDSDN);
            this.tabNhapHang.Controls.Add(this.groupBox1);
            this.tabNhapHang.Controls.Add(this.groupBoxNhapHang);
            this.tabNhapHang.Location = new System.Drawing.Point(4, 25);
            this.tabNhapHang.Name = "tabNhapHang";
            this.tabNhapHang.Padding = new System.Windows.Forms.Padding(3);
            this.tabNhapHang.Size = new System.Drawing.Size(782, 568);
            this.tabNhapHang.TabIndex = 1;
            this.tabNhapHang.Text = "Nhập hàng";
            this.tabNhapHang.UseVisualStyleBackColor = true;
            // 
            // groupBoxDSDN
            // 
            this.groupBoxDSDN.Controls.Add(this.dataGridViewDanhSachNH);
            this.groupBoxDSDN.Location = new System.Drawing.Point(4, 189);
            this.groupBoxDSDN.Name = "groupBoxDSDN";
            this.groupBoxDSDN.Size = new System.Drawing.Size(775, 190);
            this.groupBoxDSDN.TabIndex = 2;
            this.groupBoxDSDN.TabStop = false;
            this.groupBoxDSDN.Text = "Danh sách đơn nhập hàng";
            // 
            // dataGridViewDanhSachNH
            // 
            this.dataGridViewDanhSachNH.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewDanhSachNH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDanhSachNH.Location = new System.Drawing.Point(3, 26);
            this.dataGridViewDanhSachNH.Name = "dataGridViewDanhSachNH";
            this.dataGridViewDanhSachNH.RowHeadersWidth = 51;
            this.dataGridViewDanhSachNH.RowTemplate.Height = 24;
            this.dataGridViewDanhSachNH.Size = new System.Drawing.Size(773, 154);
            this.dataGridViewDanhSachNH.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonTaoPN);
            this.groupBox1.Controls.Add(this.textBoxMaNV);
            this.groupBox1.Controls.Add(this.labelMaNV);
            this.groupBox1.Controls.Add(this.textBoxNH_NCC);
            this.groupBox1.Controls.Add(this.labelTruyVet_NCC);
            this.groupBox1.Controls.Add(this.textBoxMPN);
            this.groupBox1.Controls.Add(this.labelMPN);
            this.groupBox1.Location = new System.Drawing.Point(10, 385);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(770, 168);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tạo đơn đặt hàng mới";
            // 
            // buttonTaoPN
            // 
            this.buttonTaoPN.AutoSize = true;
            this.buttonTaoPN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTaoPN.Location = new System.Drawing.Point(511, 62);
            this.buttonTaoPN.Name = "buttonTaoPN";
            this.buttonTaoPN.Size = new System.Drawing.Size(101, 38);
            this.buttonTaoPN.TabIndex = 6;
            this.buttonTaoPN.Text = "Tạo phiếu";
            this.buttonTaoPN.UseVisualStyleBackColor = true;
            this.buttonTaoPN.Click += new System.EventHandler(this.buttonTaoPN_Click);
            // 
            // textBoxMaNV
            // 
            this.textBoxMaNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMaNV.Location = new System.Drawing.Point(142, 117);
            this.textBoxMaNV.Name = "textBoxMaNV";
            this.textBoxMaNV.Size = new System.Drawing.Size(221, 27);
            this.textBoxMaNV.TabIndex = 5;
            // 
            // labelMaNV
            // 
            this.labelMaNV.AutoSize = true;
            this.labelMaNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMaNV.Location = new System.Drawing.Point(6, 120);
            this.labelMaNV.Name = "labelMaNV";
            this.labelMaNV.Size = new System.Drawing.Size(113, 20);
            this.labelMaNV.TabIndex = 4;
            this.labelMaNV.Text = "Mã nhân viên:";
            // 
            // textBoxNH_NCC
            // 
            this.textBoxNH_NCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNH_NCC.Location = new System.Drawing.Point(142, 68);
            this.textBoxNH_NCC.Name = "textBoxNH_NCC";
            this.textBoxNH_NCC.Size = new System.Drawing.Size(221, 27);
            this.textBoxNH_NCC.TabIndex = 3;
            // 
            // labelTruyVet_NCC
            // 
            this.labelTruyVet_NCC.AutoSize = true;
            this.labelTruyVet_NCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTruyVet_NCC.Location = new System.Drawing.Point(6, 71);
            this.labelTruyVet_NCC.Name = "labelTruyVet_NCC";
            this.labelTruyVet_NCC.Size = new System.Drawing.Size(117, 20);
            this.labelTruyVet_NCC.TabIndex = 2;
            this.labelTruyVet_NCC.Text = "Nhà cung cấp:";
            // 
            // textBoxMPN
            // 
            this.textBoxMPN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxMPN.Location = new System.Drawing.Point(142, 24);
            this.textBoxMPN.Name = "textBoxMPN";
            this.textBoxMPN.Size = new System.Drawing.Size(221, 27);
            this.textBoxMPN.TabIndex = 1;
            // 
            // labelMPN
            // 
            this.labelMPN.AutoSize = true;
            this.labelMPN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMPN.Location = new System.Drawing.Point(6, 27);
            this.labelMPN.Name = "labelMPN";
            this.labelMPN.Size = new System.Drawing.Size(123, 20);
            this.labelMPN.TabIndex = 0;
            this.labelMPN.Text = "Mã phiếu nhập:";
            // 
            // groupBoxNhapHang
            // 
            this.groupBoxNhapHang.Controls.Add(this.dataGridViewNhapHang);
            this.groupBoxNhapHang.Location = new System.Drawing.Point(6, 6);
            this.groupBoxNhapHang.Name = "groupBoxNhapHang";
            this.groupBoxNhapHang.Size = new System.Drawing.Size(775, 190);
            this.groupBoxNhapHang.TabIndex = 0;
            this.groupBoxNhapHang.TabStop = false;
            this.groupBoxNhapHang.Text = "Danh sách sản phẩm nhập";
            // 
            // dataGridViewNhapHang
            // 
            this.dataGridViewNhapHang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewNhapHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewNhapHang.Location = new System.Drawing.Point(3, 26);
            this.dataGridViewNhapHang.Name = "dataGridViewNhapHang";
            this.dataGridViewNhapHang.RowHeadersWidth = 51;
            this.dataGridViewNhapHang.RowTemplate.Height = 24;
            this.dataGridViewNhapHang.Size = new System.Drawing.Size(773, 151);
            this.dataGridViewNhapHang.TabIndex = 0;
            this.dataGridViewNhapHang.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // buttonDangXuat
            // 
            this.buttonDangXuat.AutoSize = true;
            this.buttonDangXuat.Location = new System.Drawing.Point(705, 3);
            this.buttonDangXuat.Name = "buttonDangXuat";
            this.buttonDangXuat.Size = new System.Drawing.Size(84, 28);
            this.buttonDangXuat.TabIndex = 1;
            this.buttonDangXuat.Text = "Đăng xuất";
            this.buttonDangXuat.UseVisualStyleBackColor = true;
            this.buttonDangXuat.Click += new System.EventHandler(this.button2_Click);
            // 
            // FormQuanTri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(799, 615);
            this.Controls.Add(this.buttonDangXuat);
            this.Controls.Add(this.tabControlQuanTri);
            this.Name = "FormQuanTri";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản trị";
            this.Load += new System.EventHandler(this.FormQuanTri_Load);
            this.tabControlQuanTri.ResumeLayout(false);
            this.tabSanPham.ResumeLayout(false);
            this.groupBoxSP_ThongTin.ResumeLayout(false);
            this.groupBoxSP_ThongTin.PerformLayout();
            this.groupBoxSP_Data.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSanPham)).EndInit();
            this.tabNhapHang.ResumeLayout(false);
            this.groupBoxDSDN.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDanhSachNH)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBoxNhapHang.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewNhapHang)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlQuanTri;
        private System.Windows.Forms.TabPage tabSanPham;
        private System.Windows.Forms.TabPage tabNhapHang;
        private System.Windows.Forms.Button buttonXoaSP;
        private System.Windows.Forms.Button buttonSuaSLT;
        private System.Windows.Forms.Button buttonTruyVet;
        private System.Windows.Forms.Button buttonThemSPVaoDSNhap;
        private System.Windows.Forms.Button buttonThemSP;
        private System.Windows.Forms.GroupBox groupBoxSP_ThongTin;
        private System.Windows.Forms.TextBox textBoxMoTa;
        private System.Windows.Forms.TextBox textBoxMaSP;
        private System.Windows.Forms.TextBox textBoxGia;
        private System.Windows.Forms.TextBox textBoxNCC;
        private System.Windows.Forms.TextBox textBoxTenSP;
        private System.Windows.Forms.Label labelMoTa;
        private System.Windows.Forms.Label labelNCC;
        private System.Windows.Forms.Label labelGiaSP;
        private System.Windows.Forms.Label labelMaSP;
        private System.Windows.Forms.Label labelTenSP;
        private System.Windows.Forms.GroupBox groupBoxSP_Data;
        private System.Windows.Forms.DataGridView dataGridViewSanPham;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonTaoPN;
        private System.Windows.Forms.TextBox textBoxMaNV;
        private System.Windows.Forms.Label labelMaNV;
        private System.Windows.Forms.TextBox textBoxNH_NCC;
        private System.Windows.Forms.Label labelTruyVet_NCC;
        private System.Windows.Forms.TextBox textBoxMPN;
        private System.Windows.Forms.Label labelMPN;
        private System.Windows.Forms.GroupBox groupBoxNhapHang;
        private System.Windows.Forms.TextBox textBoxSLT;
        private System.Windows.Forms.Label labelSLT;
        private System.Windows.Forms.Button buttonSuaGia;
        private System.Windows.Forms.GroupBox groupBoxDSDN;
        private System.Windows.Forms.DataGridView dataGridViewDanhSachNH;
        public System.Windows.Forms.DataGridView dataGridViewNhapHang;
        private System.Windows.Forms.Button buttonDangXuat;
    }
}

