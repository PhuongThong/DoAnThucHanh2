﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace QuanTriCSDLNC
{
    public partial class FormTruyVet : Form
    {
        SqlConnection connection;
        SqlCommand commandSP;
        string str = @"Data Source=DESKTOP-OMQ9N0C\SQLEXPRESS;Initial Catalog=BanHangTrucTuyen;Integrated Security=True";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable tableTV = new DataTable();
        public FormTruyVet()
        {
            InitializeComponent();
        }

        private void buttonTruyVet_TV_Click(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            commandSP = new SqlCommand("usp_TruyVet", connection);
            commandSP.CommandType = CommandType.StoredProcedure;
            commandSP.Parameters.AddWithValue("@MaSP", textBox1.Text);
            adapter.SelectCommand = commandSP;
            tableTV.Clear();
            adapter.Fill(tableTV);
            dataGridViewTruyVet.DataSource = tableTV;
            var rtn = commandSP.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
            rtn.Direction = ParameterDirection.ReturnValue;
            commandSP.ExecuteNonQuery();
            //rtn.Value = 0;
            if (rtn.Value.Equals(0))
            {
                string messages = "Không có thông tin sản phẩm cần truy vết";
                MessageBox.Show(messages);
            }
        }

        private void buttonHuyTV_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
