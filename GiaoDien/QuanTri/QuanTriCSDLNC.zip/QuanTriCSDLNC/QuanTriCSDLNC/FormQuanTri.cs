﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanTriCSDLNC
{
    public partial class FormQuanTri : Form
    {
        SqlConnection connection;
        SqlCommand commandSP;
        SqlCommand commandDSN;
        SqlCommand commandPN;
        string str = @"Data Source=DESKTOP-OMQ9N0C\SQLEXPRESS;Initial Catalog=BanHangTrucTuyen;Integrated Security=True";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable tableSP = new DataTable();
        DataTable tableDSN = new DataTable();
        DataTable tablePN = new DataTable();
        void loadData_SanPham()
        {
            commandSP = connection.CreateCommand();
            commandSP.CommandText = "select* from SanPham";
            adapter.SelectCommand = commandSP;    
            tableSP.Clear();
            adapter.Fill(tableSP);
            dataGridViewSanPham.DataSource = tableSP;
        }
        public void loadData_DSN()
        {
            commandDSN = connection.CreateCommand();
            commandDSN.CommandText = "select* from DanhSachNhap";
            adapter.SelectCommand = commandDSN;
            tableDSN.Clear();
            adapter.Fill(tableDSN);
            dataGridViewNhapHang.DataSource = tableDSN;    
        }
        void loadDaTa_PhieuNhap()
        {
            commandPN = connection.CreateCommand();
            commandPN.CommandText = "select* from PhieuNhapHang";
            adapter.SelectCommand = commandPN;
            tablePN.Clear();
            adapter.Fill(tablePN);
            dataGridViewDanhSachNH.DataSource = tablePN;
        }
        public FormQuanTri()
        {
            InitializeComponent();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void buttonTruyVet_Click(object sender, EventArgs e)
        {
            FormTruyVet form = new FormTruyVet();
            form.ShowDialog();
        }

        private void buttonTaoPN_Click(object sender, EventArgs e)
        {
            commandSP = new SqlCommand("usp_NhapHang", connection);
            commandSP.CommandType = CommandType.StoredProcedure;
            commandSP.Parameters.AddWithValue("@MaPN", textBoxMPN.Text);
            commandSP.Parameters.AddWithValue("@NhaCungCap", textBoxNH_NCC.Text);
            commandSP.Parameters.AddWithValue("@MaNV", textBoxMaNV.Text);
            //
            var rtn = commandSP.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
            rtn.Direction = ParameterDirection.ReturnValue;
            commandSP.ExecuteNonQuery();
            //rtn.Value = 0;
            if (rtn.Value.Equals(1))
            {
                string messages = "Tạo đơn nhập hàng thành công";
                MessageBox.Show(messages);
                loadDaTa_PhieuNhap();
                loadData_DSN();
            }
            else
            {
                string messagef = "Không thể tạo đơn nhập! Mời bạn kiểm tra lại thông tin.";
                MessageBox.Show(messagef);
            }
        }

        private void groupBoxSP_Data_Enter(object sender, EventArgs e)
        {

        }

        private void FormQuanTri_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            loadData_DSN();
            loadData_SanPham();
            loadDaTa_PhieuNhap();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = dataGridViewSanPham.CurrentRow.Index;
            textBoxMaSP.Text = dataGridViewSanPham.Rows[i].Cells[0].Value.ToString();
            textBoxTenSP.Text = dataGridViewSanPham.Rows[i].Cells[1].Value.ToString();
            textBoxGia.Text = dataGridViewSanPham.Rows[i].Cells[2].Value.ToString();
            textBoxMoTa.Text = dataGridViewSanPham.Rows[i].Cells[3].Value.ToString();
            textBoxSLT.Text = dataGridViewSanPham.Rows[i].Cells[4].Value.ToString();
            textBoxNCC.Text = dataGridViewSanPham.Rows[i].Cells[5].Value.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonThemSP_Click(object sender, EventArgs e)
        {
            commandSP = new SqlCommand("usp_ThemSanPham", connection);
            commandSP.CommandType = CommandType.StoredProcedure;
            commandSP.Parameters.AddWithValue("@masp", textBoxMaSP.Text);
            commandSP.Parameters.AddWithValue("@tensp", textBoxTenSP.Text);
            commandSP.Parameters.AddWithValue("@gia", textBoxGia.Text);
            commandSP.Parameters.AddWithValue("@nhaccap", textBoxNCC.Text);
            commandSP.Parameters.AddWithValue("@mota", textBoxMoTa.Text);
            var rtn = commandSP.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
            rtn.Direction = ParameterDirection.ReturnValue;
            commandSP.ExecuteNonQuery();

                
            //rtn.Value = 0;
            if (rtn.Value.Equals(1))
            {
                string messages = "Thêm sản phẩm thành công";
                MessageBox.Show(messages);
                loadData_SanPham();
            }
            else
            {
                string messagef = "Không thể thêm sản phẩm! Mời bạn kiểm tra lại thông tin.";
                MessageBox.Show(messagef);
            }
            loadData_SanPham();
            //connection.Close();
        }

        private void buttonXoaSP_Click(object sender, EventArgs e)
        {
            commandSP = new SqlCommand("usp_XoaSanPham", connection);
            commandSP.CommandType = CommandType.StoredProcedure;
            commandSP.Parameters.AddWithValue("@masp", textBoxMaSP.Text);
            var rtn = commandSP.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
            rtn.Direction = ParameterDirection.ReturnValue;
            commandSP.ExecuteNonQuery();
            //rtn.Value = 0;
            if (rtn.Value.Equals(1))
            {
                string messages = "Xóa sản phẩm thành công";
                MessageBox.Show(messages);
                loadData_SanPham();
            }
            else
            {
                string messagef = "Không thể xóa sản phẩm! Mời bạn kiểm tra lại thông tin.";
                MessageBox.Show(messagef);
            }
            loadData_SanPham();
        }

        private void buttonSua_Click(object sender, EventArgs e)
        {
            commandSP = new SqlCommand("usp_CapNhapSLT", connection);
            commandSP.CommandType = CommandType.StoredProcedure;
            commandSP.Parameters.AddWithValue("@masp", textBoxMaSP.Text);
            commandSP.Parameters.AddWithValue("@soluong", textBoxSLT.Text);
            var rtn = commandSP.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
            rtn.Direction = ParameterDirection.ReturnValue;
            commandSP.ExecuteNonQuery();
            //rtn.Value = 0;
            if (rtn.Value.Equals(1))
            {
                string messages = "Cập nhập thành công";
                MessageBox.Show(messages);
                loadData_SanPham();
            }
            else
            {
                string messagef = "Không thể cập nhập thông tin sản phẩm! Mời bạn kiểm tra lại.";
                MessageBox.Show(messagef);
            }
            loadData_SanPham();
        }

        private void buttonThemSPVaoDSNhap_Click(object sender, EventArgs e)
        {
            FormThemVaoDSN form = new FormThemVaoDSN(this);
            form.Show();
           
        }

        private void buttonSuaGia_Click(object sender, EventArgs e)
        {
            commandSP = new SqlCommand("usp_CapNhapGia", connection);
            commandSP.CommandType = CommandType.StoredProcedure;
            commandSP.Parameters.AddWithValue("@masp", textBoxMaSP.Text);
            commandSP.Parameters.AddWithValue("@gia", textBoxGia.Text);
            var rtn = commandSP.Parameters.Add("@RETURN_VALUE", SqlDbType.Int);
            rtn.Direction = ParameterDirection.ReturnValue;
            commandSP.ExecuteNonQuery();
            //rtn.Value = 0;
            if (rtn.Value.Equals(1))
            {
                string messages = "Cập nhập thành công";
                MessageBox.Show(messages);
                loadData_SanPham();
            }
            else
            {
                string messagef = "Không thể cập nhập thông tin sản phẩm! Mời bạn kiểm tra lại.";
                MessageBox.Show(messagef);
            }
            loadData_SanPham();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
